# Xamarin.Android Bindings Generator class-parse generates properties with new and override property modifiers

Bindings generator class-parse generates property modifiers with 'new' and 'override'
porperty modifiers which causes error.


  obj/Debug/generated/src/Twilio.Conversations.CapturerException.cs(37,37): 
  Error CS0113: 
  A member 
    `Twilio.Conversations.CapturerException.Message' 
  marked as override cannot be marked as new or virtual 
  (CS0113)

  obj/Debug/generated/src/Twilio.Conversations.TwilioConversationsException.cs(37,37): 
  Error CS0113: 
  A member 
    `Twilio.Conversations.TwilioConversationsException.Message' 
  marked as override cannot be marked as new or virtual 
  (CS0113) 


Errors are in classes:

*   CapturerException
*   TwilioConversationsException

which derive from java.lang.Exception and error is in generating override for
Message property.

generated cs source:

obj/generated/src/Twilio.Conversations.CapturerException.cs


		public new override unsafe string Message {
			// Metadata.xml XPath method reference: path="/api/package[@name='com.twilio.conversations']/class[@name='CapturerException']/method[@name='getMessage' and count(parameter)=0]"
			[Register ("getMessage", "()Ljava/lang/String;", "GetGetMessageHandler")]
			get {
				if (id_getMessage == IntPtr.Zero)
					id_getMessage = JNIEnv.GetMethodID (class_ref, "getMessage", "()Ljava/lang/String;");
				try {

					if (GetType () == ThresholdType)
						return JNIEnv.GetString (JNIEnv.CallObjectMethod (((global::Java.Lang.Throwable) this).Handle, id_getMessage), JniHandleOwnership.TransferLocalRef);
					else
						return JNIEnv.GetString (JNIEnv.CallNonvirtualObjectMethod (((global::Java.Lang.Throwable) this).Handle, ThresholdClass, JNIEnv.GetMethodID (ThresholdClass, "getMessage", "()Ljava/lang/String;")), JniHandleOwnership.TransferLocalRef);
				} finally {
				}
			}
		}

obj/generated/src/Twilio.Conversations.TwilioConversationsException.cs

		public new override unsafe string Message {
			// Metadata.xml XPath method reference: path="/api/package[@name='com.twilio.conversations']/class[@name='TwilioConversationsException']/method[@name='getMessage' and count(parameter)=0]"
			[Register ("getMessage", "()Ljava/lang/String;", "GetGetMessageHandler")]
			get {
				if (id_getMessage == IntPtr.Zero)
					id_getMessage = JNIEnv.GetMethodID (class_ref, "getMessage", "()Ljava/lang/String;");
				try {

					if (GetType () == ThresholdType)
						return JNIEnv.GetString (JNIEnv.CallObjectMethod (((global::Java.Lang.Throwable) this).Handle, id_getMessage), JniHandleOwnership.TransferLocalRef);
					else
						return JNIEnv.GetString (JNIEnv.CallNonvirtualObjectMethod (((global::Java.Lang.Throwable) this).Handle, ThresholdClass, JNIEnv.GetMethodID (ThresholdClass, "getMessage", "()Ljava/lang/String;")), JniHandleOwnership.TransferLocalRef);
				} finally {
				}
			}
		}


## class-parse api.xml output

*   class CapturerException
    Line 987
    *   method getMessage
        Line 1016
*   TwilioConversationsException
  Line 9035
    *   method getMessage
        Line 9078

  
