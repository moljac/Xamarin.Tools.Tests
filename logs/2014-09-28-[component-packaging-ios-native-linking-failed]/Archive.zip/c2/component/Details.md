To style your app with this theme, call
`PodradioTheme.Apply` from your AppDelegate's `FinishedLaunching` method:

```csharp
using Xamarin.Themes;
...

public override bool FinishedLaunching (UIApplication app, NSDictionary options)
{
	...
	PodradioTheme.Apply ();
}
```
 
*Screenshot assembled with [PlaceIt](http://placeit.breezi.com/).*
