using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ThemeSample")]
[assembly: AssemblyVersion("1.0.*")]

