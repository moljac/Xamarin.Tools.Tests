namespace Xamarin.Themes {
	public enum ColorScheme
	{
		Black,
		Maroon,
		Brown,
		Green
	}
}

