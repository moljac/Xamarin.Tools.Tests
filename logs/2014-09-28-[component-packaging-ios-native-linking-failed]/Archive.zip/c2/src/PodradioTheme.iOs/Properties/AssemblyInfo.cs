using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("PodradioTheme.iOS")]
[assembly: AssemblyVersion("1.0.*")]

