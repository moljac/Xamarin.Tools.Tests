namespace Xamarin.Themes {
	internal static class Attributes {
		public const string IPhone5Suffix = "@-568h";
	}
}

