# Native linking failed after packaging component

## Descriptions:

In Release (sometimes Debug) mode on the Device during component test (unpacking and testing) user gets:



Before packaging everything works as expected.

Samples containing "Component" are samples with references to dll (to reduce possibility errors in
xamarin-component.exe transformations)

## Details

2 components 

*	MarkDownSharp
*	Podradio Theme

