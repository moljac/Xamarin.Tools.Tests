# build-log diffs unpacked vs packed 

searching for: 
	XSampleMarkDownSharpXI.app

Search "XSampleMarkDownSharpXI.app" (1 hit in 1 file)
  \\vmware-host\Shared Folders\Desktop\Xamarin.Test.Toolz\logs\2014-09-28-[component-packaging-ios-native-linking-failed]\logs\build-log-diffs.md (1 hit)
	Line 3: XSampleMarkDownSharpXI.app
