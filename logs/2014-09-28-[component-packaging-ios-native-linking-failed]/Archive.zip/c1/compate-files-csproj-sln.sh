


diff \
	MarkDownSharp-1.0.0.xam/MarkDownSharp-1.0.0/samples/XSample.MarkDownSharp.XI/XSample.MarkDownSharp.XI/XSample.MarkDownSharp.XI.csproj \
	content/samples/XSample.MarkDownSharp.XI/XSample.MarkDownSharp.XI/XSample.MarkDownSharp.XI.csproj

diff \
	MarkDownSharp-1.0.0.xam/MarkDownSharp-1.0.0/samples/XSample.MarkDownSharp.XI/XSample.MarkDownSharp.XI.sln \
