﻿using System;

namespace XamarinAuth.Views
{
	public partial class PageMain
	{
		partial void SetSensitiveDataGoogleOAuth2()
		{
			oauth2 = new HolisticWare.Auth.OAuth2()
			{
				OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "1093596514437-ibfmn92v4bf27tto068heesgaohhto7n.apps.googleusercontent.com",
				OAuth2_Scope = "https://www.googleapis.com/auth/userinfo.email",
				OAuth_UriAuthorization = new Uri("https://accounts.google.com/o/oauth2/auth"), 
				OAuth_UriCallbackAKARedirect = new Uri("http://xamarin.com"),
			};
			 
			return;
		}
	}
}

