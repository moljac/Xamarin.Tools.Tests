﻿using System;

namespace XamarinAuth.Views
{
	public partial class PageMain
	{
		partial void SetSensitiveDataGithubOAuth2()
		{
			/// https://developer.github.com/v3/oauth/#scopes
			oauth2 = new HolisticWare.Auth.OAuth2()
			{
				OAuth_IdApplication_IdAPI_KeyAPI_IdClient_IdCustomer = "5b5c2d2d76e2fd9a804b",
				OAuth2_Scope = "", // "", "basic", "email",
				OAuth_UriAuthorization = new Uri("https://github.com/login/oauth/authorize"), 
				OAuth_UriCallbackAKARedirect = new Uri("http://xamarin.com"),
			};
			 
			page = new HolisticWare.XamarinForms.Authentication.PageLogin(oauth2);

			return;
		}
	}
}

